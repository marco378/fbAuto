export const FB = {
  base: "https://www.facebook.com/",
  home: "https://www.facebook.com/",
  login: "https://www.facebook.com/login",
  group: "https://www.facebook.com/groups/carpenterjobuk"
};

export const BASE_URL = "http://localhost:8000/api"